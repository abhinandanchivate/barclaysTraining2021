package com.barclays.employeeservice.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.barclays.employeeservice.model.Employee;

@Repository // repo impl will be a singleton object.
public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
