package com.barclays.employeeservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity // will inform that this class is used for ORM mapping purpose.
@Table(name = "employeeTBL") // used to provide the table name

public class Employee {

	@Id // will mark a particular column as a PK .
	private long empId;
	private String firstName;
	private String lastName;
	private float salary;
	private String address;
	
}
