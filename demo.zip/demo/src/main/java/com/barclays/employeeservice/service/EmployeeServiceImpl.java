package com.barclays.employeeservice.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.barclays.employeeservice.model.Employee;
import com.barclays.employeeservice.repository.EmployeeRepository;

@Service // it will inform to the spring that boss pls create a singlton object for this servcie.
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired // DI
	// wherever the object is required DI will provide it.
	EmployeeRepository employeeRepository;
	@Override
	public String addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		
		Employee employee2  = employeeRepository.save(employee);
		
		if(employee2!=null)
		return "success";
		else
			return "fail";
	}

	@Override
	public String updateEmployee(long id, Employee employee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional<Employee> getEmployeeById(long id) {
		// TODO Auto-generated method stub
		return employeeRepository.findById(id);
	}

	@Override
	public List<Employee> getEmployees() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteEmployeeById(long id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteEmpoloyees() {
		// TODO Auto-generated method stub

	}

}
