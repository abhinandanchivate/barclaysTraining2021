package com.barclays.testingdemo;


public interface AddService {
	public int add(int num1, int num2);
}
